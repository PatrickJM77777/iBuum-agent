"""
Automated tests for iBuum Agent 0.1.

Run with:
    pytest -v
"""

import os

# The API key must be set BEFORE app.core.config is imported anywhere,
# since Settings() reads it at import time via get_settings().
os.environ.setdefault("IBUUM_API_KEY", "test-secret-key")

import pytest
from fastapi.testclient import TestClient

from app.main import app

API_KEY = os.environ["IBUUM_API_KEY"]
ENDPOINT = "/api/v1/training/recommendation"

client = TestClient(app)


def _base_payload(**overrides) -> dict:
    payload = {
        "age": 30,
        "sex": "male",
        "height_cm": 178.0,
        "weight_kg": 80.0,
        "goal": "general_fitness",
        "training_level": "intermediate",
        "training_days_per_week": 4,
        "fatigue_level": 2,
        "last_session_type": "unknown",
        "hours_since_last_session": 48,
    }
    payload.update(overrides)
    return payload


def _headers(key: str | None = API_KEY) -> dict:
    return {"X-API-Key": key} if key else {}


# 1. Health check -------------------------------------------------------
def test_health_check_works():
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["service"] == "ibuum-agent"


# 2. Missing API key -----------------------------------------------------
def test_missing_api_key_returns_401():
    response = client.post(ENDPOINT, json=_base_payload())
    assert response.status_code == 401


# 3. Wrong API key --------------------------------------------------------
def test_wrong_api_key_returns_401():
    response = client.post(
        ENDPOINT, json=_base_payload(), headers=_headers("wrong-key")
    )
    assert response.status_code == 401


# 4. Valid API key works ---------------------------------------------------
def test_valid_api_key_works():
    response = client.post(ENDPOINT, json=_base_payload(), headers=_headers())
    assert response.status_code == 200
    body = response.json()
    assert body["agent_version"] == "0.1"
    assert "reason_codes" in body


# 5. High fatigue returns recovery/rest ------------------------------------
def test_high_fatigue_returns_rest():
    response = client.post(
        ENDPOINT,
        json=_base_payload(fatigue_level=5),
        headers=_headers(),
    )
    assert response.status_code == 200
    body = response.json()
    assert body["action"] == "rest"
    assert "HIGH_FATIGUE" in body["reason_codes"]


# 6. Beginner input prevents excessively high intensity ---------------------
def test_beginner_never_gets_high_intensity():
    response = client.post(
        ENDPOINT,
        json=_base_payload(training_level="beginner", fatigue_level=1),
        headers=_headers(),
    )
    assert response.status_code == 200
    body = response.json()
    assert body["intensity"] != "high"


# 7. Recent lower-body session avoids another demanding lower-body session --
def test_recent_lower_body_session_avoids_repeat():
    response = client.post(
        ENDPOINT,
        json=_base_payload(last_session_type="lower_body", hours_since_last_session=10),
        headers=_headers(),
    )
    assert response.status_code == 200
    body = response.json()
    assert body["recommended_session"] != "lower_body"
    assert "RECENT_LOWER_BODY_SESSION" in body["reason_codes"]


# 8. Female user without cycle_context works normally -----------------------
def test_female_without_cycle_context_works():
    response = client.post(
        ENDPOINT,
        json=_base_payload(sex="female"),
        headers=_headers(),
    )
    assert response.status_code == 200
    body = response.json()
    assert body["action"] in {"train", "recovery", "rest", "request_more_data"}


# 9. cycle_context is optional ----------------------------------------------
def test_cycle_context_is_optional():
    payload = _base_payload(sex="female")
    assert "cycle_context" not in payload
    response = client.post(ENDPOINT, json=payload, headers=_headers())
    assert response.status_code == 200


# 10. High menstrual discomfort influences recommendation without medical advice
def test_high_menstrual_discomfort_influences_recommendation():
    response = client.post(
        ENDPOINT,
        json=_base_payload(
            sex="female",
            cycle_context={"phase": "menstruation", "discomfort": "high"},
        ),
        headers=_headers(),
    )
    assert response.status_code == 200
    body = response.json()
    assert "CYCLE_HIGH_DISCOMFORT" in body["reason_codes"]
    assert body["intensity"] in {"low", "not_applicable"}
    # No natural-language medical advice — response stays structured.
    assert isinstance(body["reason_codes"], list)
    assert all(isinstance(code, str) for code in body["reason_codes"])
